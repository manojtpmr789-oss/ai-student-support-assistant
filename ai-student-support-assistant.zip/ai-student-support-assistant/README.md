# AI Student Support Assistant

An AI-powered college support assistant that answers student questions using
**Retrieval-Augmented Generation (RAG)**, purpose-built **AI tools**, and
**conversation memory** — grounded strictly in the college's own uploaded
regulations, syllabi, notices, FAQs, and academic calendar. If the answer
isn't in the documents, it says so instead of guessing.

> Built as a complete, runnable final-year / capstone project. Ships with
> demo data so it works immediately after setup.

---

## 1. Features

- **RAG pipeline**: upload PDF/DOCX/TXT → extract → clean → chunk → index →
  retrieve → generate a grounded answer with cited sources.
- **8 AI tools** the assistant can call: notice search, regulation search,
  syllabus search, FAQ search, academic calendar search, important-dates
  lookup, a calculator, and a general document search — wired up as real
  Claude tool-use, not a scripted menu.
- **Conversation memory**: short-term session memory for follow-up
  questions ("what happens if I'm below that?"), plus a persistent
  "concise vs detailed" answer-style preference per student.
- **Source transparency**: every RAG answer shows which document(s) it came
  from, with a high/medium/low confidence indicator based on retrieval
  relevance.
- **Notice summarizer**: uploading or publishing a notice automatically
  extracts a short summary, an important date, and a required action.
- **Student side**: chat assistant, dashboard, notices, syllabus,
  regulations, academic calendar, FAQ, profile/preferences.
- **Admin side**: JWT-protected admin console — document upload & processing
  status, notice management, FAQ management, and a chatbot analytics
  dashboard (most-asked topics, confidence breakdown, feedback).
- **Security**: JWT auth, bcrypt password hashing, role-based access
  (student/admin), file type & size validation, and no raw backend errors
  ever shown to the user.

## 2. Architecture

```
ai-student-support-assistant/
  backend/
    app/
      api/         # FastAPI routers (auth, documents, notices, faq, chat, ...)
      auth/         # JWT + password hashing
      models/       # SQLAlchemy models
      schemas/      # Pydantic request/response schemas
      rag/          # text extraction, chunking, TF-IDF vector store
      tools/        # the 8 AI tools + Anthropic tool-use definitions
      memory/       # conversation history + preference memory
      services/     # LLM orchestration (RAG + tools), notice summarizer
      seed.py        # loads demo admin account + sample documents
      main.py        # FastAPI app
    knowledge_base/  # sample regulation/syllabus/calendar text files (DEMO DATA)
    requirements.txt
    .env.example
  frontend/
    src/
      components/    # Sidebar, ChatMessage helpers, SourceList, etc.
      pages/          # Landing, Chat, Dashboard, Admin*, ...
      context/        # AuthContext
      services/       # api.js (axios client)
      layouts/        # AppLayout (sidebar shell)
    package.json
  README.md
```

### Why TF-IDF instead of a neural embedding model?

The retrieval layer (`backend/app/rag/vector_store.py`) uses scikit-learn's
TF-IDF + cosine similarity instead of a downloaded embedding model. This
keeps the whole RAG pipeline **runnable completely offline** — no extra API
key, no multi-hundred-MB model download, no GPU. It works well for a
college-document corpus of the size this project targets. The retrieval
interface (`VectorStore.search(query, top_k, category)`) is intentionally
shaped like what you'd get from Chroma/FAISS + a real embedding model, so
swapping it later means re-implementing one class, not rewriting the app.

### Swapping in MongoDB

The demo runs on SQLite (`DATABASE_URL=sqlite:///./student_assistant.db`) so
it needs zero setup. To use MongoDB instead, you would replace
`app/database.py` + the SQLAlchemy models in `app/models/` with a Motor/
PyMongo client and Pydantic document models — the API routers themselves
don't need to change since they only depend on the `db` session object
being passed in.

## 3. Technology Stack

**Frontend:** React 18, Vite, Tailwind CSS, React Router, Recharts, Lucide icons
**Backend:** Python, FastAPI, SQLAlchemy, Pydantic
**AI:** Anthropic Claude (RAG answer generation + tool-calling)
**Retrieval:** scikit-learn TF-IDF vector store (see note above)
**Database:** SQLite by default (swappable to MongoDB — see above)
**Auth:** JWT (python-jose) + bcrypt password hashing, role-based access
**Document processing:** pypdf, python-docx

## 4. Prerequisites

- Python 3.10+
- Node.js 18+
- An Anthropic API key (for the chat/RAG-generation step) — get one at
  https://console.anthropic.com

## 5. Backend setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# then edit .env and set LLM_API_KEY=sk-ant-... (required for the chat endpoint)

uvicorn app.main:app --reload --port 8000
```

On first startup the app automatically:
- creates the SQLite database and tables,
- seeds a demo admin account,
- processes the sample regulation/syllabus/academic-calendar documents in
  `knowledge_base/` and builds the vector index,
- seeds 5 demo notices and 5 demo FAQs.

API docs: http://localhost:8000/docs

## 6. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env    # VITE_API_URL=http://localhost:8000
npm run dev
```

App: http://localhost:5173

## 7. Default demo accounts

| Role  | Email               | Password   |
|-------|---------------------|------------|
| Admin | admin@college.edu   | Admin@123  |

Students register their own account from the **Register** page (no seed
needed — any new account defaults to the `student` role).

**Change the default admin password / set your own in `.env` before any
real deployment** — it's a DEMO credential only.

## 8. Uploading college documents

1. Sign in as admin → **Documents**.
2. Fill in a title, category (regulation / syllabus / notice / faq /
   academic_calendar / examination / department / general), and choose a
   PDF, DOCX, or TXT file (max 15 MB).
3. On upload the file is extracted, cleaned, chunked, and the vector index
   is rebuilt automatically — status shows Processing → Processed (or
   Failed, with a friendly error, if extraction fails).

## 9. Testing the RAG chatbot

1. Sign in as a student (register a new account, or reuse one you made).
2. Go to **Ask AI** and try:
   - "What is the attendance requirement?"
   - "What happens if I have less than that?" (tests conversation memory —
     "that" should resolve to the attendance % from the previous answer)
   - "How many credits do I need in Semester 5?"
   - "What are the latest notices?"
   - Ask something not in any document (e.g. "What's the canteen menu
     today?") — it should reply with the fixed "I couldn't find this
     information..." message instead of inventing an answer.
3. Check the **Sources used** section and confidence indicator under each
   answer.

## 10. RAG workflow (what happens on each question)

```
question
  -> TF-IDF retrieval over all processed document chunks
  -> confidence scored from top similarity score
  -> retrieved context + last few turns of conversation sent to Claude,
     with the 8 AI tools available for it to call if useful
  -> Claude generates an answer using ONLY that context/tool output
  -> if nothing relevant was found at all, the fixed "not found" message
     is returned instead of a generated answer
  -> answer + sources + confidence + tools used are stored and returned
```

## 11. Common errors and fixes

| Symptom | Fix |
|---|---|
| Chat replies "AI service is temporarily unavailable" | `LLM_API_KEY` is missing/invalid in `backend/.env`, or you've hit a rate limit. |
| Chat always says "I couldn't find this information..." | No documents processed yet, or your question doesn't match anything uploaded — upload a relevant document as admin. |
| `ModuleNotFoundError` on backend start | Re-run `pip install -r requirements.txt` inside the activated virtualenv. |
| CORS errors in the browser console | Confirm the backend is running on port 8000 and `VITE_API_URL` in `frontend/.env` matches it. |
| Upload fails with "Unsupported file type" | Only `.pdf`, `.docx`, `.txt`, `.md` are accepted. |
| 401 errors right after login | The JWT may have expired (`ACCESS_TOKEN_EXPIRE_MINUTES` in `.env`) — sign in again. |

## 12. Future enhancements

- Swap TF-IDF for a hosted embedding model + Chroma/FAISS for semantic
  (not just keyword-overlap) retrieval.
- Streaming chat responses (token-by-token).
- Per-document access control (e.g. department-restricted syllabi).
- Move from SQLite to MongoDB/Postgres for multi-instance deployments.
- Push notifications for new notices and approaching deadlines.
- Full dark-mode theme toggle in the UI.

---

*Sample documents, notices, and FAQs shipped in this repo are clearly
labeled as DEMO DATA and should be replaced with your institution's real,
approved documents before any production use.*
