import { Routes, Route, Navigate } from 'react-router-dom'
import ProtectedRoute from './components/ProtectedRoute.jsx'
import AppLayout from './layouts/AppLayout.jsx'

import Landing from './pages/Landing.jsx'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import StudentDashboard from './pages/StudentDashboard.jsx'
import Chat from './pages/Chat.jsx'
import Notices from './pages/Notices.jsx'
import Syllabus from './pages/Syllabus.jsx'
import Regulations from './pages/Regulations.jsx'
import AcademicCalendar from './pages/AcademicCalendar.jsx'
import FAQ from './pages/FAQ.jsx'
import Profile from './pages/Profile.jsx'

import AdminOverview from './pages/AdminOverview.jsx'
import AdminDocuments from './pages/AdminDocuments.jsx'
import AdminNotices from './pages/AdminNotices.jsx'
import AdminFAQ from './pages/AdminFAQ.jsx'
import AdminAnalytics from './pages/AdminAnalytics.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<StudentDashboard />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/notices" element={<Notices />} />
        <Route path="/syllabus" element={<Syllabus />} />
        <Route path="/regulations" element={<Regulations />} />
        <Route path="/calendar" element={<AcademicCalendar />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/profile" element={<Profile />} />
      </Route>

      <Route element={<ProtectedRoute requireAdmin><AppLayout admin /></ProtectedRoute>}>
        <Route path="/admin" element={<AdminOverview />} />
        <Route path="/admin/documents" element={<AdminDocuments />} />
        <Route path="/admin/notices" element={<AdminNotices />} />
        <Route path="/admin/faq" element={<AdminFAQ />} />
        <Route path="/admin/analytics" element={<AdminAnalytics />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
