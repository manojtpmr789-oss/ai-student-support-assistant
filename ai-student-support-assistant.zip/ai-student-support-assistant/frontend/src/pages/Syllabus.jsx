import DocumentCategoryPage from './DocumentCategoryPage.jsx'

export default function Syllabus() {
  return (
    <DocumentCategoryPage
      category="syllabus"
      eyebrow="Academics"
      title="Syllabus"
      subtitle="Subjects, units, and credits for each semester."
      emptyText="No syllabus documents have been uploaded yet."
    />
  )
}
