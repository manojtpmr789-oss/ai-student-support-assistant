import { useEffect, useRef, useState } from 'react'
import { Send, Copy, RotateCcw, ThumbsUp, ThumbsDown, Plus, Trash2, MessageSquare } from 'lucide-react'
import * as api from '../services/api.js'
import { friendlyError } from '../services/api.js'
import ConfidenceIndicator from '../components/ConfidenceIndicator.jsx'
import SourceList from '../components/SourceList.jsx'

const STARTER_QUESTIONS = [
  'What is the attendance requirement?',
  'What are the examination regulations?',
  'What is the syllabus for this semester?',
  'What are the latest college notices?',
]

export default function Chat() {
  const [conversations, setConversations] = useState([])
  const [conversationId, setConversationId] = useState(null)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [suggested, setSuggested] = useState(STARTER_QUESTIONS)
  const [error, setError] = useState('')
  const bottomRef = useRef(null)

  const refreshConversations = () => {
    api.listConversations().then((res) => setConversations(res.data)).catch(() => {})
  }

  useEffect(() => { refreshConversations() }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, sending])

  const openConversation = async (id) => {
    setError('')
    const res = await api.getConversation(id)
    setConversationId(id)
    setMessages(res.data.messages)
  }

  const startNewChat = () => {
    setConversationId(null)
    setMessages([])
    setSuggested(STARTER_QUESTIONS)
    setError('')
  }

  const removeConversation = async (id, e) => {
    e.stopPropagation()
    await api.deleteConversation(id)
    if (id === conversationId) startNewChat()
    refreshConversations()
  }

  const send = async (text) => {
    const question = (text ?? input).trim()
    if (!question || sending) return
    setError('')
    setInput('')
    setMessages((prev) => [...prev, { id: `tmp-${Date.now()}`, role: 'user', content: question }])
    setSending(true)
    try {
      const res = await api.sendMessage(question, conversationId)
      setConversationId(res.data.conversation_id)
      setMessages((prev) => [...prev, {
        id: res.data.message_id,
        role: 'assistant',
        content: res.data.answer,
        sources: res.data.sources,
        confidence: res.data.confidence,
        tools_used: res.data.tools_used,
      }])
      setSuggested(res.data.suggested_questions?.length ? res.data.suggested_questions : STARTER_QUESTIONS)
      refreshConversations()
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setSending(false)
    }
  }

  const regenerate = () => {
    const lastUser = [...messages].reverse().find((m) => m.role === 'user')
    if (lastUser) send(lastUser.content)
  }

  const copyText = (text) => navigator.clipboard.writeText(text)

  const feedback = (messageId, rating) => {
    if (messageId.startsWith('tmp-')) return
    api.sendFeedback(messageId, rating).catch(() => {})
  }

  return (
    <div className="flex h-screen">
      {/* conversation history rail */}
      <div className="w-56 shrink-0 border-r border-ink-950/10 hidden lg:flex flex-col">
        <div className="p-4">
          <button onClick={startNewChat}
            className="w-full flex items-center justify-center gap-2 text-sm bg-ink-950 text-paper rounded py-2 hover:bg-ink-900 transition-colors">
            <Plus size={15} /> New chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto scrollbar-thin px-2 space-y-1">
          {conversations.map((c) => (
            <button key={c.id} onClick={() => openConversation(c.id)}
              className={`w-full text-left px-3 py-2 rounded text-xs flex items-start gap-2 group ${
                c.id === conversationId ? 'bg-teal-50 text-ink-950' : 'text-ink-950/60 hover:bg-ink-950/5'
              }`}>
              <MessageSquare size={13} className="mt-0.5 shrink-0" />
              <span className="flex-1 truncate">{c.title}</span>
              <Trash2 size={12} className="opacity-0 group-hover:opacity-60 shrink-0" onClick={(e) => removeConversation(c.id, e)} />
            </button>
          ))}
        </div>
      </div>

      {/* main chat column */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="px-8 py-5 border-b border-ink-950/10 flex items-center justify-between">
          <div>
            <h1 className="font-serif text-xl">Ask AI</h1>
            <p className="text-xs text-ink-950/50">Answers are grounded in official college documents.</p>
          </div>
          <button onClick={startNewChat} className="lg:hidden text-xs border border-ink-950/15 rounded px-3 py-1.5">New chat</button>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin px-8 py-6">
          {messages.length === 0 && (
            <div className="max-w-lg mx-auto mt-10 text-center">
              <p className="font-serif text-2xl mb-2">How can I help you today?</p>
              <p className="text-sm text-ink-950/55 mb-6">Ask about attendance, exams, syllabus, notices, or academic dates.</p>
              <div className="grid sm:grid-cols-2 gap-2 text-left">
                {STARTER_QUESTIONS.map((q) => (
                  <button key={q} onClick={() => send(q)}
                    className="border border-ink-950/12 rounded px-3 py-2.5 text-sm hover:border-teal-500 hover:bg-teal-50/50 transition-colors">
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="max-w-2xl mx-auto space-y-5">
            {messages.map((m, idx) => (
              <div key={m.id ?? idx} className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
                {m.role === 'user' ? (
                  <div className="bg-ink-950 text-paper rounded-lg rounded-tr-sm px-4 py-2.5 max-w-[80%] text-sm">
                    {m.content}
                  </div>
                ) : (
                  <div className="bg-white border border-ink-950/10 rounded-lg rounded-tl-sm px-4 py-3 max-w-[85%] text-sm shadow-panel">
                    <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
                    <SourceList sources={m.sources} />
                    <div className="mt-3 flex items-center justify-between">
                      {m.confidence ? <ConfidenceIndicator level={m.confidence} /> : <span />}
                      <div className="flex items-center gap-2.5 text-ink-950/40">
                        <button title="Copy" onClick={() => copyText(m.content)} className="hover:text-ink-950"><Copy size={13} /></button>
                        {idx === messages.length - 1 && (
                          <button title="Regenerate" onClick={regenerate} className="hover:text-ink-950"><RotateCcw size={13} /></button>
                        )}
                        <button title="Good answer" onClick={() => feedback(m.id, 'up')} className="hover:text-teal-600"><ThumbsUp size={13} /></button>
                        <button title="Bad answer" onClick={() => feedback(m.id, 'down')} className="hover:text-red-600"><ThumbsDown size={13} /></button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {sending && (
              <div className="flex justify-start">
                <div className="bg-white border border-ink-950/10 rounded-lg rounded-tl-sm px-4 py-3 shadow-panel">
                  <span className="flex gap-1">
                    <span className="h-1.5 w-1.5 bg-ink-950/30 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="h-1.5 w-1.5 bg-ink-950/30 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="h-1.5 w-1.5 bg-ink-950/30 rounded-full animate-bounce" />
                  </span>
                </div>
              </div>
            )}

            {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</p>}
          </div>
          <div ref={bottomRef} />
        </div>

        {messages.length > 0 && (
          <div className="px-8 py-2 max-w-2xl mx-auto w-full flex flex-wrap gap-1.5">
            {suggested.slice(0, 4).map((q) => (
              <button key={q} onClick={() => send(q)}
                className="text-xs border border-ink-950/12 rounded-full px-3 py-1 text-ink-950/60 hover:border-teal-500 hover:text-teal-600 transition-colors">
                {q}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={(e) => { e.preventDefault(); send() }} className="px-8 py-5 border-t border-ink-950/10">
          <div className="max-w-2xl mx-auto flex items-end gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
              rows={1}
              placeholder="Ask about attendance, exams, syllabus, notices..."
              className="flex-1 resize-none border border-ink-950/15 rounded-lg px-4 py-3 text-sm focus:border-teal-500 outline-none max-h-32"
            />
            <button type="submit" disabled={sending || !input.trim()}
              className="bg-ink-950 hover:bg-ink-900 text-paper rounded-lg p-3 disabled:opacity-40 transition-colors">
              <Send size={16} />
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
