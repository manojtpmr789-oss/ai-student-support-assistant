import DocumentCategoryPage from './DocumentCategoryPage.jsx'

export default function Regulations() {
  return (
    <DocumentCategoryPage
      category="regulation"
      eyebrow="Academics"
      title="Regulations"
      subtitle="Attendance, passing criteria, internal assessment, and examination rules."
      emptyText="No regulation documents have been uploaded yet."
    />
  )
}
