import { useEffect, useState } from 'react'
import { Trash2 } from 'lucide-react'
import * as api from '../services/api.js'
import { friendlyError } from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function AdminFAQ() {
  const [faqs, setFaqs] = useState([])
  const [form, setForm] = useState({ question: '', answer: '', category: 'general' })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const refresh = () => api.getFaqs().then((r) => setFaqs(r.data)).catch(() => {})
  useEffect(() => { refresh() }, [])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      await api.createFaq(form)
      setForm({ question: '', answer: '', category: 'general' })
      refresh()
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setSaving(false)
    }
  }

  const remove = async (id) => { await api.deleteFaq(id); refresh() }

  return (
    <div>
      <PageHeader eyebrow="Admin" title="FAQ Management" subtitle="Maintain the list of frequently asked questions." />
      <div className="p-8 grid lg:grid-cols-[1fr_1.4fr] gap-8">
        <form onSubmit={submit} className="border border-ink-950/10 rounded-lg p-5 bg-white/50 h-fit space-y-4">
          <h2 className="font-serif text-lg">New FAQ</h2>
          {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</p>}
          <div>
            <label className="text-xs text-ink-950/60">Question</label>
            <input required value={form.question} onChange={(e) => setForm({ ...form, question: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <div>
            <label className="text-xs text-ink-950/60">Answer</label>
            <textarea required rows={4} value={form.answer} onChange={(e) => setForm({ ...form, answer: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <button disabled={saving} type="submit"
            className="w-full bg-ink-950 hover:bg-ink-900 text-paper py-2.5 rounded text-sm font-medium transition-colors disabled:opacity-60">
            {saving ? 'Saving...' : 'Add FAQ'}
          </button>
        </form>

        <div className="space-y-2">
          {faqs.map((f) => (
            <div key={f.id} className="border border-ink-950/10 rounded-lg p-4 bg-white/50 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium">{f.question}</p>
                <p className="text-xs text-ink-950/50 mt-1 line-clamp-2">{f.answer}</p>
              </div>
              <button onClick={() => remove(f.id)} className="text-ink-950/40 hover:text-red-600 shrink-0"><Trash2 size={15} /></button>
            </div>
          ))}
          {faqs.length === 0 && <p className="text-sm text-ink-950/45">No FAQs yet.</p>}
        </div>
      </div>
    </div>
  )
}
