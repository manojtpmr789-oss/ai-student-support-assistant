import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import { friendlyError } from '../services/api.js'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const user = await login(email, password)
      navigate(user.role === 'admin' ? '/admin' : '/dashboard')
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <Link to="/" className="font-serif text-xl text-paper block text-center mb-8">AI Student Support</Link>
        <div className="bg-paper rounded shadow-panel p-8">
          <h1 className="font-serif text-2xl mb-1">Welcome back</h1>
          <p className="text-sm text-ink-950/55 mb-6">Sign in to ask the assistant a question.</p>

          {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2 mb-4">{error}</p>}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs text-ink-950/60">Email</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
            </div>
            <div>
              <label className="text-xs text-ink-950/60">Password</label>
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
            </div>
            <button disabled={loading} type="submit"
              className="w-full bg-ink-950 hover:bg-ink-900 text-paper py-2.5 rounded text-sm font-medium transition-colors disabled:opacity-60">
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>

          <p className="text-xs text-ink-950/50 mt-5">
            Demo admin: admin@college.edu / Admin@123
          </p>
          <p className="text-sm text-ink-950/60 mt-4">
            No account? <Link to="/register" className="text-teal-600 font-medium">Register</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
