import { useEffect, useState } from 'react'
import { Trash2 } from 'lucide-react'
import * as api from '../services/api.js'
import { friendlyError } from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function AdminNotices() {
  const [notices, setNotices] = useState([])
  const [form, setForm] = useState({ title: '', content: '', target_students: 'All students' })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const refresh = () => api.getNotices().then((r) => setNotices(r.data)).catch(() => {})
  useEffect(() => { refresh() }, [])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      await api.createNotice(form)
      setForm({ title: '', content: '', target_students: 'All students' })
      refresh()
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setSaving(false)
    }
  }

  const remove = async (id) => { await api.deleteNotice(id); refresh() }

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Notice Management" subtitle="Publish notices. A summary, date, and action are auto-extracted." />
      <div className="p-8 grid lg:grid-cols-[1fr_1.4fr] gap-8">
        <form onSubmit={submit} className="border border-ink-950/10 rounded-lg p-5 bg-white/50 h-fit space-y-4">
          <h2 className="font-serif text-lg">New notice</h2>
          {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</p>}
          <div>
            <label className="text-xs text-ink-950/60">Title</label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <div>
            <label className="text-xs text-ink-950/60">Content</label>
            <textarea required rows={6} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <div>
            <label className="text-xs text-ink-950/60">Target students</label>
            <input value={form.target_students} onChange={(e) => setForm({ ...form, target_students: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <button disabled={saving} type="submit"
            className="w-full bg-ink-950 hover:bg-ink-900 text-paper py-2.5 rounded text-sm font-medium transition-colors disabled:opacity-60">
            {saving ? 'Publishing...' : 'Publish notice'}
          </button>
        </form>

        <div className="space-y-2">
          {notices.map((n) => (
            <div key={n.id} className="border border-ink-950/10 rounded-lg p-4 bg-white/50 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium">{n.title}</p>
                <p className="text-xs text-ink-950/50 mt-1 line-clamp-2">{n.summary}</p>
                {n.important_date && <p className="text-xs text-brass-600 mt-1">{n.important_date}</p>}
              </div>
              <button onClick={() => remove(n.id)} className="text-ink-950/40 hover:text-red-600 shrink-0"><Trash2 size={15} /></button>
            </div>
          ))}
          {notices.length === 0 && <p className="text-sm text-ink-950/45">No notices yet.</p>}
        </div>
      </div>
    </div>
  )
}
