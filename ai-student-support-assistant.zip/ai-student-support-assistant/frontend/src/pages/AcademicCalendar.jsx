import { useEffect, useState } from 'react'
import { Calendar } from 'lucide-react'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function AcademicCalendar() {
  const [data, setData] = useState({ calendar_excerpts: [], upcoming_deadlines: [] })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getCalendar().then((r) => setData(r.data)).finally(() => setLoading(false))
  }, [])

  return (
    <div>
      <PageHeader eyebrow="Academics" title="Academic Calendar" subtitle="Important dates for the current term, extracted from official documents and notices." />
      <div className="p-8 grid md:grid-cols-2 gap-8 max-w-4xl">
        <div>
          <h2 className="font-serif text-lg mb-3">Upcoming dates</h2>
          {loading && <p className="text-sm text-ink-950/50">Loading...</p>}
          <div className="space-y-2">
            {data.upcoming_deadlines.length === 0 && !loading && <p className="text-sm text-ink-950/45">No upcoming deadlines found.</p>}
            {data.upcoming_deadlines.map((d, i) => (
              <div key={i} className="flex items-start gap-2.5 border-l-2 border-teal-500 pl-3 py-1">
                <Calendar size={14} className="mt-0.5 text-teal-500" />
                <div>
                  <p className="text-sm font-medium">{d.title}</p>
                  {d.date && <p className="text-xs text-ink-950/50">{d.date}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h2 className="font-serif text-lg mb-3">Full calendar</h2>
          <div className="space-y-3">
            {data.calendar_excerpts.map((c, i) => (
              <div key={i} className="border border-ink-950/10 rounded-lg p-4 bg-white/50">
                <p className="text-xs font-medium text-ink-950/50 mb-1">{c.document_title}</p>
                <pre className="whitespace-pre-wrap font-sans text-sm text-ink-950/75">{c.content}</pre>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
