import { useEffect, useState } from 'react'
import { Upload, Trash2, CheckCircle2, Clock, XCircle } from 'lucide-react'
import * as api from '../services/api.js'
import { friendlyError } from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

const CATEGORIES = ['regulation', 'syllabus', 'notice', 'faq', 'academic_calendar', 'examination', 'department', 'general']

const STATUS_ICON = {
  processed: <CheckCircle2 size={14} className="text-teal-600" />,
  processing: <Clock size={14} className="text-brass-500" />,
  failed: <XCircle size={14} className="text-red-500" />,
}

export default function AdminDocuments() {
  const [docs, setDocs] = useState([])
  const [form, setForm] = useState({ title: '', description: '', category: 'regulation' })
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState('')

  const refresh = () => api.listDocuments().then((r) => setDocs(r.data)).catch(() => {})
  useEffect(() => { refresh() }, [])

  const submit = async (e) => {
    e.preventDefault()
    if (!file) { setError('Please choose a PDF, DOCX, or TXT file.'); return }
    setError('')
    setUploading(true)
    const fd = new FormData()
    fd.append('title', form.title)
    fd.append('description', form.description)
    fd.append('category', form.category)
    fd.append('file', file)
    try {
      await api.uploadDocument(fd)
      setForm({ title: '', description: '', category: 'regulation' })
      setFile(null)
      e.target.reset()
      refresh()
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setUploading(false)
    }
  }

  const remove = async (id) => {
    await api.deleteDocument(id)
    refresh()
  }

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Document Management" subtitle="Upload institutional documents to the knowledge base." />
      <div className="p-8 grid lg:grid-cols-[1fr_1.4fr] gap-8">
        <form onSubmit={submit} className="border border-ink-950/10 rounded-lg p-5 bg-white/50 h-fit space-y-4">
          <h2 className="font-serif text-lg">Upload a document</h2>
          {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</p>}
          <div>
            <label className="text-xs text-ink-950/60">Title</label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <div>
            <label className="text-xs text-ink-950/60">Description</label>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={2} className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
          </div>
          <div>
            <label className="text-xs text-ink-950/60">Category</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
              className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm bg-white focus:border-teal-500 outline-none">
              {CATEGORIES.map((c) => <option key={c} value={c}>{c.replace('_', ' ')}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-ink-950/60">File (PDF, DOCX, or TXT — max 15MB)</label>
            <input type="file" accept=".pdf,.docx,.txt,.md" onChange={(e) => setFile(e.target.files[0])}
              className="mt-1 w-full text-sm" />
          </div>
          <button disabled={uploading} type="submit"
            className="w-full flex items-center justify-center gap-2 bg-ink-950 hover:bg-ink-900 text-paper py-2.5 rounded text-sm font-medium transition-colors disabled:opacity-60">
            <Upload size={15} /> {uploading ? 'Processing...' : 'Upload & process'}
          </button>
        </form>

        <div>
          <h2 className="font-serif text-lg mb-3">Knowledge base ({docs.length})</h2>
          <div className="space-y-2">
            {docs.map((d) => (
              <div key={d.id} className="border border-ink-950/10 rounded-lg p-4 bg-white/50 flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{d.title}</p>
                  <p className="text-xs text-ink-950/50 mt-0.5 capitalize">{d.category.replace('_', ' ')} · {d.chunk_count} chunks</p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="flex items-center gap-1 text-xs text-ink-950/60 capitalize">{STATUS_ICON[d.status]} {d.status}</span>
                  <button onClick={() => remove(d.id)} className="text-ink-950/40 hover:text-red-600"><Trash2 size={15} /></button>
                </div>
              </div>
            ))}
            {docs.length === 0 && <p className="text-sm text-ink-950/45">No documents uploaded yet.</p>}
          </div>
        </div>
      </div>
    </div>
  )
}
