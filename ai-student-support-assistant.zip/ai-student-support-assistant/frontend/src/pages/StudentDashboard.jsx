import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { MessageSquare, Bell, BookOpen, Scale, Calendar, HelpCircle, ArrowRight } from 'lucide-react'
import * as api from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import PageHeader from '../components/PageHeader.jsx'

const cards = [
  { to: '/chat', icon: MessageSquare, label: 'Ask AI', desc: 'Get instant answers from college documents' },
  { to: '/notices', icon: Bell, label: 'Notices', desc: 'Latest circulars and announcements' },
  { to: '/syllabus', icon: BookOpen, label: 'Syllabus', desc: 'Subjects, units and credits' },
  { to: '/regulations', icon: Scale, label: 'Regulations', desc: 'Attendance, exams, and passing rules' },
  { to: '/calendar', icon: Calendar, label: 'Academic Calendar', desc: 'Term dates and deadlines' },
  { to: '/faq', icon: HelpCircle, label: 'FAQs', desc: 'Common student questions' },
]

export default function StudentDashboard() {
  const { user } = useAuth()
  const [notices, setNotices] = useState([])
  const [conversations, setConversations] = useState([])

  useEffect(() => {
    api.getNotices().then((r) => setNotices(r.data.slice(0, 3))).catch(() => {})
    api.listConversations().then((r) => setConversations(r.data.slice(0, 3))).catch(() => {})
  }, [])

  return (
    <div>
      <PageHeader eyebrow="Student dashboard" title={`Welcome back, ${user?.name?.split(' ')[0] || 'there'}`} subtitle="Everything you need, in one place." />
      <div className="p-8 grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h2 className="font-serif text-lg mb-4">Quick actions</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {cards.map(({ to, icon: Icon, label, desc }) => (
              <Link key={to} to={to} className="border border-ink-950/10 rounded-lg p-4 hover:border-teal-500 hover:bg-teal-50/40 transition-colors group">
                <Icon size={18} className="text-teal-500" />
                <p className="font-medium mt-2.5 text-sm">{label}</p>
                <p className="text-xs text-ink-950/50 mt-1">{desc}</p>
              </Link>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-serif text-lg">Latest notices</h2>
              <Link to="/notices" className="text-xs text-teal-600 flex items-center gap-1">View all <ArrowRight size={12} /></Link>
            </div>
            <div className="space-y-2">
              {notices.length === 0 && <p className="text-sm text-ink-950/45">No notices yet.</p>}
              {notices.map((n) => (
                <div key={n.id} className="border-l-2 border-brass-400 pl-3 py-1">
                  <p className="text-sm font-medium">{n.title}</p>
                  {n.important_date && <p className="text-xs text-ink-950/50">{n.important_date}</p>}
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-serif text-lg">Recent conversations</h2>
              <Link to="/chat" className="text-xs text-teal-600 flex items-center gap-1">Open chat <ArrowRight size={12} /></Link>
            </div>
            <div className="space-y-2">
              {conversations.length === 0 && <p className="text-sm text-ink-950/45">No conversations yet — ask your first question.</p>}
              {conversations.map((c) => (
                <p key={c.id} className="text-sm text-ink-950/70 truncate">{c.title}</p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
