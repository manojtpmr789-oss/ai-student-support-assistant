import { useEffect, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

const COLORS = ['#2c7d75', '#b0872b', '#b3492f']

export default function AdminAnalytics() {
  const [stats, setStats] = useState(null)

  useEffect(() => {
    api.getAnalytics().then((r) => setStats(r.data)).catch(() => {})
  }, [])

  if (!stats) return <div className="p-8 text-sm text-ink-950/50">Loading analytics...</div>

  const topicData = stats.most_asked_topics.map((t) => ({ name: t.topic.replace('_', ' '), count: t.count }))
  const confidenceData = Object.entries(stats.confidence_breakdown).map(([k, v]) => ({ name: k, value: v }))

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Chatbot Analytics" subtitle="Usage statistics for the AI assistant." />
      <div className="p-8 grid md:grid-cols-2 gap-8">
        <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
          <h2 className="font-serif text-lg mb-4">Most asked topics</h2>
          {topicData.length === 0 ? <p className="text-sm text-ink-950/45">No data yet.</p> : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={topicData}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#2c7d75" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
          <h2 className="font-serif text-lg mb-4">Answer confidence</h2>
          {confidenceData.length === 0 ? <p className="text-sm text-ink-950/45">No data yet.</p> : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={confidenceData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90}>
                  {confidenceData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50 md:col-span-2">
          <h2 className="font-serif text-lg mb-4">Summary</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-sm">
            <div><p className="text-ink-950/50 text-xs">Total AI responses</p><p className="font-serif text-2xl mt-1">{stats.total_ai_responses}</p></div>
            <div><p className="text-ink-950/50 text-xs">Total questions</p><p className="font-serif text-2xl mt-1">{stats.total_questions}</p></div>
            <div><p className="text-ink-950/50 text-xs">Unanswered</p><p className="font-serif text-2xl mt-1">{stats.unanswered_questions}</p></div>
            <div><p className="text-ink-950/50 text-xs">Documents indexed</p><p className="font-serif text-2xl mt-1">{stats.total_documents}</p></div>
          </div>
        </div>
      </div>
    </div>
  )
}
