import { useState } from 'react'
import { useAuth } from '../context/AuthContext.jsx'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function Profile() {
  const { user, refreshUser } = useAuth()
  const [style, setStyle] = useState(user?.preferred_style || 'concise')
  const [saved, setSaved] = useState(false)

  const save = async (value) => {
    setStyle(value)
    const res = await api.updatePreferences(value)
    refreshUser(res.data)
    setSaved(true)
    setTimeout(() => setSaved(false), 1500)
  }

  return (
    <div>
      <PageHeader eyebrow="Account" title="Profile & Settings" subtitle="Manage your account and assistant preferences." />
      <div className="p-8 max-w-xl space-y-8">
        <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
          <h2 className="font-serif text-lg mb-3">Account details</h2>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-ink-950/50">Name</dt><dd>{user?.name}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-950/50">Email</dt><dd>{user?.email}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-950/50">Role</dt><dd className="capitalize">{user?.role}</dd></div>
          </dl>
        </div>

        <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
          <h2 className="font-serif text-lg mb-1">Assistant response style</h2>
          <p className="text-xs text-ink-950/50 mb-4">This preference is remembered and applied to every future answer.</p>
          <div className="flex gap-2">
            {['concise', 'detailed'].map((opt) => (
              <button key={opt} onClick={() => save(opt)}
                className={`px-4 py-2 rounded text-sm capitalize border transition-colors ${
                  style === opt ? 'bg-ink-950 text-paper border-ink-950' : 'border-ink-950/15 hover:border-teal-500'
                }`}>
                {opt}
              </button>
            ))}
          </div>
          {saved && <p className="text-xs text-teal-600 mt-2">Saved.</p>}
        </div>
      </div>
    </div>
  )
}
