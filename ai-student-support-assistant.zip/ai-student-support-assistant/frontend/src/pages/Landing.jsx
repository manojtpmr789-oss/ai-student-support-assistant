import { Link } from 'react-router-dom'
import { FileSearch, Wrench, Brain, ArrowRight, BookOpen, Bell, Scale, Calendar } from 'lucide-react'

const steps = [
  { n: '01', title: 'Ask a question', body: 'Type any question about attendance, exams, syllabus, or notices in plain language.' },
  { n: '02', title: 'Retrieve the right document', body: 'The assistant searches official college regulations, syllabi, notices, and FAQs for relevant passages.' },
  { n: '03', title: 'Get a grounded answer', body: 'A response is generated strictly from what was found, with the source document shown alongside it.' },
]

const features = [
  { icon: FileSearch, title: 'Retrieval-Augmented Generation', body: 'Answers are grounded in your college\u2019s own regulation, syllabus, and notice documents \u2014 never invented.' },
  { icon: Wrench, title: 'Purpose-built AI tools', body: 'Dedicated tools search notices, regulations, syllabi, FAQs, and the academic calendar, plus a calculator for credit and attendance math.' },
  { icon: Brain, title: 'Conversation memory', body: 'Follow-up questions like \u201cwhat happens if I\u2019m below that?\u201d are understood in context.' },
]

const quickLinks = [
  { icon: Scale, label: 'Regulations' },
  { icon: BookOpen, label: 'Syllabus' },
  { icon: Bell, label: 'Notices' },
  { icon: Calendar, label: 'Academic calendar' },
]

export default function Landing() {
  return (
    <div className="bg-paper text-ink-950">
      {/* Hero */}
      <header className="bg-ink-950 text-paper">
        <nav className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
          <p className="font-serif text-lg">AI Student Support</p>
          <div className="flex items-center gap-4 text-sm">
            <Link to="/login" className="text-paper/70 hover:text-paper transition-colors">Sign in</Link>
            <Link to="/register" className="bg-brass-500 hover:bg-brass-400 text-ink-950 px-4 py-2 rounded transition-colors font-medium">
              Get started
            </Link>
          </div>
        </nav>

        <div className="max-w-6xl mx-auto px-6 pt-16 pb-24 grid md:grid-cols-[1fr_1.4fr] gap-12">
          <div className="hidden md:block">
            <div className="rule-light" />
            <dl className="mt-6 space-y-5 text-sm text-paper/60">
              <div>
                <dt className="text-paper/35">Built for</dt>
                <dd className="text-paper mt-0.5">Students, faculty & administration</dd>
              </div>
              <div>
                <dt className="text-paper/35">Grounded in</dt>
                <dd className="text-paper mt-0.5">Your college's own documents</dd>
              </div>
              <div>
                <dt className="text-paper/35">Powered by</dt>
                <dd className="text-paper mt-0.5">RAG, AI tools & memory</dd>
              </div>
            </dl>
          </div>
          <div>
            <h1 className="font-serif text-5xl md:text-6xl leading-[1.08]">
              Your college knowledge, powered by AI.
            </h1>
            <p className="mt-6 text-paper/70 text-lg max-w-xl">
              Ask about regulations, syllabus, notices, academic rules, and college
              information — and get reliable answers instantly, sourced directly
              from official documents.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link to="/register" className="inline-flex items-center gap-2 bg-brass-500 hover:bg-brass-400 text-ink-950 px-5 py-3 rounded font-medium transition-colors">
                Ask AI <ArrowRight size={16} />
              </Link>
              <a href="#how-it-works" className="inline-flex items-center gap-2 border border-paper/25 hover:border-paper/50 px-5 py-3 rounded transition-colors">
                Explore features
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Quick links strip */}
      <div className="border-b border-ink-950/10">
        <div className="max-w-6xl mx-auto px-6 py-5 flex flex-wrap gap-x-8 gap-y-3">
          {quickLinks.map(({ icon: Icon, label }) => (
            <span key={label} className="flex items-center gap-2 text-sm text-ink-950/60">
              <Icon size={15} className="text-teal-500" /> {label}
            </span>
          ))}
        </div>
      </div>

      {/* How it works */}
      <section id="how-it-works" className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="font-serif text-3xl mb-10">How it works</h2>
        <div className="grid md:grid-cols-3 gap-10">
          {steps.map((s) => (
            <div key={s.n}>
              <p className="font-serif text-3xl text-brass-500">{s.n}</p>
              <p className="mt-3 font-medium">{s.title}</p>
              <p className="mt-2 text-sm text-ink-950/60 leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="rule max-w-6xl mx-auto" />

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="font-serif text-3xl mb-10">What makes it reliable</h2>
        <div className="grid md:grid-cols-3 gap-10">
          {features.map(({ icon: Icon, title, body }) => (
            <div key={title} className="border border-ink-950/10 rounded p-6 bg-white/40">
              <Icon size={20} className="text-teal-500" />
              <p className="mt-4 font-medium">{title}</p>
              <p className="mt-2 text-sm text-ink-950/60 leading-relaxed">{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-ink-950 text-paper">
        <div className="max-w-6xl mx-auto px-6 py-16 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <p className="font-serif text-2xl max-w-md">Stop searching through PDFs. Just ask.</p>
          <Link to="/register" className="inline-flex items-center gap-2 bg-brass-500 hover:bg-brass-400 text-ink-950 px-5 py-3 rounded font-medium transition-colors">
            Create your account <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      <footer className="max-w-6xl mx-auto px-6 py-8 text-xs text-ink-950/40 flex justify-between">
        <span>AI Student Support Assistant — final-year project demo</span>
        <span>Built with RAG · AI Tools · Memory</span>
      </footer>
    </div>
  )
}
