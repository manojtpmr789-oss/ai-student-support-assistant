import { useEffect, useState } from 'react'
import { FileText, MessageSquare, HelpCircle, AlertTriangle } from 'lucide-react'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

const StatCard = ({ icon: Icon, label, value }) => (
  <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
    <Icon size={18} className="text-teal-500" />
    <p className="font-serif text-3xl mt-3">{value}</p>
    <p className="text-xs text-ink-950/50 mt-1">{label}</p>
  </div>
)

export default function AdminOverview() {
  const [stats, setStats] = useState(null)

  useEffect(() => {
    api.getAnalytics().then((r) => setStats(r.data)).catch(() => {})
  }, [])

  return (
    <div>
      <PageHeader eyebrow="Admin" title="Overview" subtitle="A snapshot of assistant activity and the knowledge base." />
      <div className="p-8">
        {!stats && <p className="text-sm text-ink-950/50">Loading...</p>}
        {stats && (
          <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatCard icon={MessageSquare} label="Total questions asked" value={stats.total_questions} />
              <StatCard icon={MessageSquare} label="Questions today" value={stats.questions_today} />
              <StatCard icon={FileText} label="Documents in knowledge base" value={stats.total_documents} />
              <StatCard icon={AlertTriangle} label="Unanswered questions" value={stats.unanswered_questions} />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
                <h2 className="font-serif text-lg mb-3">Most asked topics</h2>
                {stats.most_asked_topics.length === 0 && <p className="text-sm text-ink-950/45">No questions logged yet.</p>}
                <div className="space-y-2">
                  {stats.most_asked_topics.map((t) => (
                    <div key={t.topic} className="flex items-center gap-3">
                      <span className="text-xs w-32 truncate capitalize text-ink-950/60">{t.topic.replace('_', ' ')}</span>
                      <div className="flex-1 h-2 bg-ink-950/5 rounded-full overflow-hidden">
                        <div className="h-full bg-teal-500" style={{ width: `${Math.min(100, t.count * 20)}%` }} />
                      </div>
                      <span className="text-xs text-ink-950/50 w-5 text-right">{t.count}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
                <h2 className="font-serif text-lg mb-3">Student feedback</h2>
                <div className="flex items-center gap-8">
                  <div>
                    <p className="font-serif text-3xl text-teal-600">{stats.user_feedback.up}</p>
                    <p className="text-xs text-ink-950/50">Helpful</p>
                  </div>
                  <div>
                    <p className="font-serif text-3xl text-red-500">{stats.user_feedback.down}</p>
                    <p className="text-xs text-ink-950/50">Not helpful</p>
                  </div>
                </div>
                <div className="mt-5 pt-4 border-t border-ink-950/10">
                  <p className="text-xs text-ink-950/50 mb-2">Answer confidence breakdown</p>
                  {Object.entries(stats.confidence_breakdown).map(([k, v]) => (
                    <div key={k} className="flex justify-between text-sm">
                      <span className="capitalize">{k}</span><span>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
