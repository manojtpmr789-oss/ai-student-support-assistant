import { useEffect, useState } from 'react'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function DocumentCategoryPage({ category, eyebrow, title, subtitle, emptyText }) {
  const [docs, setDocs] = useState([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(null)

  useEffect(() => {
    api.getByCategory(category).then((r) => {
      setDocs(r.data.documents)
      if (r.data.documents.length) setOpen(r.data.documents[0].id)
    }).finally(() => setLoading(false))
  }, [category])

  return (
    <div>
      <PageHeader eyebrow={eyebrow} title={title} subtitle={subtitle} />
      <div className="p-8 max-w-3xl">
        {loading && <p className="text-sm text-ink-950/50">Loading...</p>}
        {!loading && docs.length === 0 && <p className="text-sm text-ink-950/50">{emptyText}</p>}
        <div className="space-y-3">
          {docs.map((d) => (
            <div key={d.id} className="border border-ink-950/10 rounded-lg bg-white/50 overflow-hidden">
              <button
                onClick={() => setOpen(open === d.id ? null : d.id)}
                className="w-full text-left px-5 py-4 flex items-center justify-between"
              >
                <div>
                  <p className="font-medium text-sm">{d.title}</p>
                  {d.description && <p className="text-xs text-ink-950/50 mt-0.5">{d.description}</p>}
                </div>
                <span className="text-ink-950/40 text-xs">{open === d.id ? 'Hide' : 'View'}</span>
              </button>
              {open === d.id && (
                <div className="px-5 pb-5 border-t border-ink-950/10 pt-4">
                  <pre className="whitespace-pre-wrap font-sans text-sm text-ink-950/75 leading-relaxed">{d.content}</pre>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
