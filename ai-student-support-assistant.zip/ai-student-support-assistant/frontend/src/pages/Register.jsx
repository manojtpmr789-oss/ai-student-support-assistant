import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import { friendlyError } from '../services/api.js'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const user = await register(form.name, form.email, form.password, 'student')
      navigate(user.role === 'admin' ? '/admin' : '/dashboard')
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <Link to="/" className="font-serif text-xl text-paper block text-center mb-8">AI Student Support</Link>
        <div className="bg-paper rounded shadow-panel p-8">
          <h1 className="font-serif text-2xl mb-1">Create your account</h1>
          <p className="text-sm text-ink-950/55 mb-6">Registers as a student account.</p>

          {error && <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2 mb-4">{error}</p>}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs text-ink-950/60">Full name</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
            </div>
            <div>
              <label className="text-xs text-ink-950/60">Email</label>
              <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
            </div>
            <div>
              <label className="text-xs text-ink-950/60">Password</label>
              <input type="password" required minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="mt-1 w-full border border-ink-950/15 rounded px-3 py-2 text-sm focus:border-teal-500 outline-none" />
              <p className="text-[11px] text-ink-950/40 mt-1">At least 8 characters.</p>
            </div>
            <button disabled={loading} type="submit"
              className="w-full bg-ink-950 hover:bg-ink-900 text-paper py-2.5 rounded text-sm font-medium transition-colors disabled:opacity-60">
              {loading ? 'Creating account...' : 'Create account'}
            </button>
          </form>

          <p className="text-sm text-ink-950/60 mt-5">
            Already have an account? <Link to="/login" className="text-teal-600 font-medium">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
