import { useEffect, useState } from 'react'
import { Calendar, Users, ArrowRight } from 'lucide-react'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function Notices() {
  const [notices, setNotices] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getNotices().then((r) => setNotices(r.data)).finally(() => setLoading(false))
  }, [])

  return (
    <div>
      <PageHeader eyebrow="Announcements" title="College Notices" subtitle="Official circulars and announcements from the college." />
      <div className="p-8 max-w-3xl space-y-4">
        {loading && <p className="text-sm text-ink-950/50">Loading notices...</p>}
        {!loading && notices.length === 0 && <p className="text-sm text-ink-950/50">No notices published yet.</p>}
        {notices.map((n) => (
          <div key={n.id} className="border border-ink-950/10 rounded-lg p-5 bg-white/50">
            <div className="flex items-start justify-between gap-4">
              <h3 className="font-medium">{n.title}</h3>
              {n.is_demo !== false && <span className="text-[10px] text-brass-600 bg-brass-50 border border-brass-100 rounded-full px-2 py-0.5 shrink-0">DEMO DATA</span>}
            </div>
            <p className="text-sm text-ink-950/65 mt-2 leading-relaxed">{n.summary || n.content}</p>
            <div className="flex flex-wrap gap-4 mt-3 text-xs text-ink-950/50">
              {n.important_date && <span className="flex items-center gap-1"><Calendar size={12} /> {n.important_date}</span>}
              {n.target_students && <span className="flex items-center gap-1"><Users size={12} /> {n.target_students}</span>}
            </div>
            {n.required_action && (
              <p className="text-xs text-teal-700 mt-2 flex items-start gap-1"><ArrowRight size={12} className="mt-0.5 shrink-0" /> {n.required_action}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
