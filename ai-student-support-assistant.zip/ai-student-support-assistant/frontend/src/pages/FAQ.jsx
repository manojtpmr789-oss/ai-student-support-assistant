import { useEffect, useState } from 'react'
import * as api from '../services/api.js'
import PageHeader from '../components/PageHeader.jsx'

export default function FAQ() {
  const [faqs, setFaqs] = useState([])
  const [open, setOpen] = useState(null)

  useEffect(() => {
    api.getFaqs().then((r) => setFaqs(r.data))
  }, [])

  return (
    <div>
      <PageHeader eyebrow="Support" title="Frequently Asked Questions" subtitle="Quick answers to common student questions." />
      <div className="p-8 max-w-3xl space-y-2">
        {faqs.length === 0 && <p className="text-sm text-ink-950/50">No FAQs published yet.</p>}
        {faqs.map((f) => (
          <div key={f.id} className="border border-ink-950/10 rounded-lg bg-white/50 overflow-hidden">
            <button onClick={() => setOpen(open === f.id ? null : f.id)} className="w-full text-left px-5 py-4 flex items-center justify-between gap-4">
              <span className="text-sm font-medium">{f.question}</span>
              <span className="text-ink-950/40 text-xs shrink-0">{open === f.id ? 'Hide' : 'Show'}</span>
            </button>
            {open === f.id && (
              <div className="px-5 pb-4 border-t border-ink-950/10 pt-3">
                <p className="text-sm text-ink-950/70 leading-relaxed">{f.answer}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
