import { createContext, useContext, useEffect, useState } from 'react'
import * as api from '../services/api.js'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('assistant_user')
    return raw ? JSON.parse(raw) : null
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('assistant_token')
    if (!token) {
      setLoading(false)
      return
    }
    api.getMe()
      .then((res) => {
        setUser(res.data)
        localStorage.setItem('assistant_user', JSON.stringify(res.data))
      })
      .catch(() => {
        localStorage.removeItem('assistant_token')
        localStorage.removeItem('assistant_user')
        setUser(null)
      })
      .finally(() => setLoading(false))
  }, [])

  const persist = (data) => {
    localStorage.setItem('assistant_token', data.access_token)
    localStorage.setItem('assistant_user', JSON.stringify(data.user))
    setUser(data.user)
  }

  const login = async (email, password) => {
    const res = await api.login(email, password)
    persist(res.data)
    return res.data.user
  }

  const register = async (name, email, password, role) => {
    const res = await api.register(name, email, password, role)
    persist(res.data)
    return res.data.user
  }

  const logout = () => {
    localStorage.removeItem('assistant_token')
    localStorage.removeItem('assistant_user')
    setUser(null)
  }

  const refreshUser = (updated) => {
    setUser(updated)
    localStorage.setItem('assistant_user', JSON.stringify(updated))
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
