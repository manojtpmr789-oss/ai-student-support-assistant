export default function PageHeader({ eyebrow, title, subtitle }) {
  return (
    <div className="px-8 pt-8 pb-6 border-b border-ink-950/10">
      {eyebrow && <p className="text-xs text-teal-600 font-medium mb-1">{eyebrow}</p>}
      <h1 className="font-serif text-2xl">{title}</h1>
      {subtitle && <p className="text-sm text-ink-950/55 mt-1">{subtitle}</p>}
    </div>
  )
}
