import { FileText } from 'lucide-react'

export default function SourceList({ sources }) {
  if (!sources || sources.length === 0) return null
  return (
    <div className="mt-3 pt-3 border-t border-ink-950/10">
      <p className="text-[11px] tracking-wide text-ink-950/50 mb-1.5">Sources used</p>
      <ul className="space-y-1">
        {sources.map((s, i) => (
          <li key={i} className="flex items-start gap-1.5 text-xs text-ink-950/70">
            <FileText size={13} className="mt-0.5 shrink-0 text-brass-500" />
            <span>
              <span className="font-medium">{s.document_title}</span>
              {s.category ? <span className="text-ink-950/40"> · {s.category.replace('_', ' ')}</span> : null}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}
