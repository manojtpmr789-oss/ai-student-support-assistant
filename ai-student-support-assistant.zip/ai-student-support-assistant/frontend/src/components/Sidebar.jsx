import { NavLink, useNavigate } from 'react-router-dom'
import {
  MessageSquare, LayoutDashboard, Bell, BookOpen, Scale, Calendar,
  HelpCircle, User, LogOut, ShieldCheck,
} from 'lucide-react'
import { useAuth } from '../context/AuthContext.jsx'

const studentLinks = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/chat', label: 'Ask AI', icon: MessageSquare },
  { to: '/notices', label: 'Notices', icon: Bell },
  { to: '/syllabus', label: 'Syllabus', icon: BookOpen },
  { to: '/regulations', label: 'Regulations', icon: Scale },
  { to: '/calendar', label: 'Academic Calendar', icon: Calendar },
  { to: '/faq', label: 'FAQ', icon: HelpCircle },
  { to: '/profile', label: 'Profile', icon: User },
]

const adminLinks = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard },
  { to: '/admin/documents', label: 'Documents', icon: BookOpen },
  { to: '/admin/notices', label: 'Notices', icon: Bell },
  { to: '/admin/faq', label: 'FAQs', icon: HelpCircle },
  { to: '/admin/analytics', label: 'Analytics', icon: ShieldCheck },
]

export default function Sidebar({ admin = false }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const links = admin ? adminLinks : studentLinks

  return (
    <aside className="w-60 shrink-0 bg-ink-950 text-paper flex flex-col h-screen sticky top-0">
      <div className="px-5 py-6">
        <p className="font-serif text-lg leading-tight">AI Student<br/>Support</p>
        <p className="text-[11px] text-paper/45 mt-1">{admin ? 'Admin console' : 'Assistant'}</p>
      </div>
      <div className="rule-light mx-5" />
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto scrollbar-thin">
        {links.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/admin'}
            className={({ isActive }) =>
              `flex items-center gap-2.5 px-3 py-2 rounded text-sm transition-colors ${
                isActive ? 'bg-paper/10 text-paper' : 'text-paper/60 hover:text-paper hover:bg-paper/5'
              }`
            }
          >
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="rule-light mx-5" />
      <div className="px-5 py-4">
        <p className="text-sm text-paper/85 truncate">{user?.name}</p>
        <p className="text-[11px] text-paper/40 truncate mb-3">{user?.email}</p>
        <button
          onClick={() => { logout(); navigate('/login') }}
          className="flex items-center gap-2 text-xs text-paper/60 hover:text-paper transition-colors"
        >
          <LogOut size={14} /> Sign out
        </button>
      </div>
    </aside>
  )
}
