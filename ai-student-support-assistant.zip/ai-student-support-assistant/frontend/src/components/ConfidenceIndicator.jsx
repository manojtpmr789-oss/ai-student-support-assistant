const CONFIG = {
  high: { label: 'High confidence', color: '#2c7d75' },
  medium: { label: 'Medium confidence', color: '#b0872b' },
  low: { label: 'Low confidence', color: '#b3492f' },
}

export default function ConfidenceIndicator({ level }) {
  const cfg = CONFIG[level] || CONFIG.low
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-ink-950/60">
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: cfg.color }} />
      {cfg.label}
    </span>
  )
}
