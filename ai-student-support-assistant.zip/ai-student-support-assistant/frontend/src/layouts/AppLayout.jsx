import { Outlet } from 'react-router-dom'
import Sidebar from '../components/Sidebar.jsx'

export default function AppLayout({ admin = false }) {
  return (
    <div className="flex min-h-screen bg-paper">
      <Sidebar admin={admin} />
      <main className="flex-1 min-w-0">
        <Outlet />
      </main>
    </div>
  )
}
