import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('assistant_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('assistant_token')
      localStorage.removeItem('assistant_user')
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login'
      }
    }
    return Promise.reject(err)
  }
)

export const friendlyError = (err) =>
  err?.response?.data?.detail || 'Something went wrong. Please try again.'

// --- Auth ---
export const login = (email, password) => api.post('/api/auth/login', { email, password })
export const register = (name, email, password, role) =>
  api.post('/api/auth/register', { name, email, password, role })
export const getMe = () => api.get('/api/auth/me')
export const updatePreferences = (preferred_style) =>
  api.put('/api/auth/preferences', { preferred_style })

// --- Chat ---
export const sendMessage = (message, conversation_id) =>
  api.post('/api/chat', { message, conversation_id })
export const listConversations = () => api.get('/api/conversations')
export const getConversation = (id) => api.get(`/api/conversations/${id}`)
export const deleteConversation = (id) => api.delete(`/api/conversations/${id}`)
export const sendFeedback = (message_id, rating) =>
  api.post('/api/conversations/feedback', { message_id, rating })

// --- Content ---
export const getNotices = () => api.get('/api/notices')
export const createNotice = (payload) => api.post('/api/notices', payload)
export const deleteNotice = (id) => api.delete(`/api/notices/${id}`)

export const getFaqs = () => api.get('/api/faq')
export const createFaq = (payload) => api.post('/api/faq', payload)
export const deleteFaq = (id) => api.delete(`/api/faq/${id}`)

export const getCalendar = () => api.get('/api/calendar')
export const getByCategory = (category) => api.get(`/api/knowledge/${category}`)

// --- Admin: documents & analytics ---
export const listDocuments = () => api.get('/api/documents')
export const uploadDocument = (formData) =>
  api.post('/api/documents/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
export const deleteDocument = (id) => api.delete(`/api/documents/${id}`)
export const getAnalytics = () => api.get('/api/analytics')

export default api
