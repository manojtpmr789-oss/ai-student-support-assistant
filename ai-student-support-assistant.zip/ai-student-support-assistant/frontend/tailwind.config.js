/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0d1321',
          900: '#141c2f',
          800: '#1c2740',
        },
        paper: '#f6f4ee',
        brass: {
          50: '#fbf6ec',
          100: '#f3e6c8',
          400: '#c9a13b',
          500: '#b0872b',
          600: '#8e6c20',
        },
        teal: {
          50: '#eef7f6',
          400: '#3f9c93',
          500: '#2c7d75',
          600: '#20605a',
        },
      },
      fontFamily: {
        serif: ['"Source Serif 4"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        panel: '0 1px 2px rgba(13,19,33,0.06), 0 8px 24px -12px rgba(13,19,33,0.25)',
      },
    },
  },
  plugins: [],
}
