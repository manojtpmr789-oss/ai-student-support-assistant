"""Seeds the DB with a demo admin account and sample college documents/notices/FAQs
so the app works immediately after setup. Idempotent - safe to run multiple times."""
import os
from sqlalchemy.orm import Session

from app.database import SessionLocal, engine, Base
from app.models.models import User, Document, Notice, FAQ
from app.auth.security import hash_password
from app.rag.pipeline import process_document, rebuild_vector_index
from app.services.summarizer import summarize_notice
from app.config import settings

KB_DIR = settings.knowledge_base_path

SAMPLE_DOCS = [
    ("Academic Regulations 2025", "Attendance, passing criteria, internal assessment, exam rules, leave rules", "regulation", "regulations/academic_regulations_2025.txt"),
    ("CSE Semester 5 Syllabus", "Subjects, credits, and units for Semester 5 CSE", "syllabus", "syllabus/cse_semester5_syllabus.txt"),
    ("Academic Calendar 2026", "Important academic dates for the even semester 2026", "academic_calendar", "academic_calendar/academic_calendar_2026.txt"),
]

SAMPLE_NOTICES = [
    (
        "Semester Examination Registration Now Open",
        "This is to inform all students that registration for the upcoming Semester "
        "End Examinations is now open. Students must complete their registration "
        "on or before 25 April 2026. Late registration will be accepted until 2 May 2026 "
        "with a fine of Rs. 500. Students with attendance below 65% are not eligible "
        "to register. Kindly complete the process through the student portal.",
        "All students",
    ),
    (
        "Internal Assessment Test 2 Schedule Released",
        "The schedule for Internal Assessment Test 2 has been released and will be "
        "conducted from 16 to 21 March 2026. Students must carry their ID cards. "
        "The detailed subject-wise timetable is available on the notice board and "
        "student portal.",
        "All students",
    ),
    (
        "Holiday Notice - Holi",
        "The college will remain closed on 4 March 2026 on account of Holi. "
        "Regular classes will resume from 5 March 2026.",
        "All students and staff",
    ),
    (
        "Final Year Project Submission Deadline",
        "All final year students must submit their project reports and source code "
        "before 20 April 2026. Late submissions will not be accepted under any "
        "circumstances. Students should kindly coordinate with their project guides "
        "for the final review before submission.",
        "Final year students",
    ),
    (
        "Fee Payment Reminder for Next Semester",
        "Students are informed that the last date for fee payment for the next "
        "semester is 15 July 2026. Please complete the payment through the online "
        "portal to avoid a late fee penalty.",
        "All students",
    ),
]

SAMPLE_FAQS = [
    ("What is the minimum attendance required to appear for exams?", "You must maintain at least 75% attendance. Between 65-74% you may get condonation with a medical certificate (max 2 times). Below 65% you cannot appear for the exam.", "regulation"),
    ("How many credits do I need in Semester 5?", "Semester 5 offers 22 credits total. You need a minimum of 18 credits to be eligible for Semester 6 registration.", "syllabus"),
    ("How do I apply for a Bonafide Certificate?", "Submit a written request to the college office with your ID card copy and the applicable fee. Certificates are usually issued within 5 working days.", "general"),
    ("What happens if I use my phone during an exam?", "It is treated as malpractice. Your exam for that subject will be cancelled and you may face disciplinary action including suspension.", "examination"),
    ("When does the summer vacation start?", "Summer vacation runs from 8 June to 2 August 2026, right after the semester end examinations.", "academic_calendar"),
]


def seed():
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        if not db.query(User).filter(User.email == settings.default_admin_email).first():
            db.add(User(
                name="College Admin",
                email=settings.default_admin_email,
                hashed_password=hash_password(settings.default_admin_password),
                role="admin",
            ))
            db.commit()
            print(f"Seeded demo admin: {settings.default_admin_email} / {settings.default_admin_password}")

        admin = db.query(User).filter(User.email == settings.default_admin_email).first()

        if db.query(Document).count() == 0:
            for title, desc, category, relpath in SAMPLE_DOCS:
                filepath = os.path.join(KB_DIR, relpath)
                doc = Document(
                    title=title, description=desc, category=category,
                    filename=os.path.basename(relpath), filepath=filepath,
                    status="processing", uploaded_by=admin.id if admin else None,
                )
                db.add(doc)
                db.commit()
                db.refresh(doc)
                process_document(db, doc)
            print(f"Seeded {len(SAMPLE_DOCS)} demo documents into the knowledge base")

        if db.query(Notice).count() == 0:
            for title, content, target in SAMPLE_NOTICES:
                auto = summarize_notice(content)
                db.add(Notice(
                    title=title, content=content, summary=auto["summary"],
                    important_date=auto["important_date"], target_students=target,
                    required_action=auto["required_action"], deadline=auto["deadline"],
                    is_demo=True,
                ))
            db.commit()
            print(f"Seeded {len(SAMPLE_NOTICES)} demo notices")

        if db.query(FAQ).count() == 0:
            for q, a, cat in SAMPLE_FAQS:
                db.add(FAQ(question=q, answer=a, category=cat, is_demo=True))
            db.commit()
            print(f"Seeded {len(SAMPLE_FAQS)} demo FAQs")

        rebuild_vector_index(db)
    finally:
        db.close()


if __name__ == "__main__":
    seed()
