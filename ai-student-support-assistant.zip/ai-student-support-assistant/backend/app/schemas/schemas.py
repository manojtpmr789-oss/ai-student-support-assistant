from pydantic import BaseModel, EmailStr
from typing import Optional, List
import datetime


class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: Optional[str] = "student"


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    role: str
    preferred_style: str

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class DocumentOut(BaseModel):
    id: str
    title: str
    description: str
    category: str
    filename: str
    status: str
    chunk_count: int
    created_at: datetime.datetime

    class Config:
        from_attributes = True


class NoticeIn(BaseModel):
    title: str
    content: str
    important_date: Optional[str] = ""
    target_students: Optional[str] = "All students"
    required_action: Optional[str] = ""
    deadline: Optional[str] = ""


class NoticeOut(NoticeIn):
    id: str
    summary: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True


class FAQIn(BaseModel):
    question: str
    answer: str
    category: Optional[str] = "general"


class FAQOut(FAQIn):
    id: str

    class Config:
        from_attributes = True


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None


class SourceRef(BaseModel):
    document_title: str
    category: str
    snippet: str


class ChatResponse(BaseModel):
    conversation_id: str
    message_id: str
    answer: str
    sources: List[SourceRef]
    confidence: str
    tools_used: List[str]
    suggested_questions: List[str]


class FeedbackIn(BaseModel):
    message_id: str
    rating: str  # up | down


class PreferenceIn(BaseModel):
    preferred_style: str
