"""
Core RAG + AI-tools orchestration.

Flow per the spec:
  question -> embed/retrieve from knowledge base -> (optionally call AI tools)
  -> send retrieved context to the LLM -> generate grounded answer
  -> return answer + sources + confidence

If nothing relevant is found anywhere (vector search AND tools), the
assistant must refuse to invent an answer and returns the fixed
"couldn't find this information" message instead.
"""
import json
from sqlalchemy.orm import Session
from anthropic import Anthropic, APIError

from app.config import settings
from app.models.models import User
from app.rag.vector_store import vector_store
from app.tools.tools import TOOL_DEFINITIONS, dispatch_tool
from app.memory.memory import get_recent_history, style_instruction

NOT_FOUND_MESSAGE = (
    "I couldn't find this information in the available college documents. "
    "Please check with the concerned department/office."
)

SYSTEM_PROMPT = """You are the AI Student Support Assistant for a college.

Rules you MUST follow:
1. Answer ONLY using information found in the "RETRIEVED CONTEXT" block below
   and/or the results of tool calls you make. NEVER invent college rules,
   dates, numbers, or policies that are not present in that context.
2. If the retrieved context and tools do not contain the answer, reply
   with exactly: "{not_found}"
3. When you do answer from the context, keep answers simple, student-friendly,
   concise, and use bullet points or short steps when helpful.
4. You have tools available (notice/regulation/syllabus/FAQ/calendar/important
   dates/calculator/general document search). Call a tool whenever it would
   help find the answer, rather than guessing.
5. {style}
""".format(not_found=NOT_FOUND_MESSAGE, style="{style}")


def _client() -> Anthropic:
    if not settings.llm_api_key:
        raise RuntimeError("LLM_API_KEY is not configured in the backend .env file")
    return Anthropic(api_key=settings.llm_api_key)


def _confidence_from_scores(scores: list[float]) -> str:
    if not scores:
        return "low"
    top = max(scores)
    if top >= 0.35:
        return "high"
    if top >= 0.15:
        return "medium"
    return "low"


def generate_answer(db: Session, user: User, question: str, conversation_id: str) -> dict:
    """Returns dict: answer, sources[], confidence, tools_used[]"""
    # 1. Initial broad retrieval across the whole knowledge base for context + confidence
    initial_chunks = vector_store.search(question, top_k=5)
    scores = [c.score for c in initial_chunks]
    confidence = _confidence_from_scores(scores)

    if not initial_chunks:
        return {
            "answer": NOT_FOUND_MESSAGE,
            "sources": [],
            "confidence": "low",
            "tools_used": [],
        }

    context_block = "\n\n".join(
        f"[Source: {c.document_title} | category: {c.category} | relevance: {c.score:.2f}]\n{c.content}"
        for c in initial_chunks
    )

    history = get_recent_history(db, conversation_id)
    system = SYSTEM_PROMPT.format(style=style_instruction(user))
    system += f"\n\nRETRIEVED CONTEXT:\n{context_block}\n"

    messages = history + [{"role": "user", "content": question}]

    client = _client()
    tools_used: list[str] = []
    sources_seen = {(c.document_title, c.category): c.content[:300] for c in initial_chunks}

    try:
        response = client.messages.create(
            model=settings.llm_model,
            max_tokens=1000,
            system=system,
            messages=messages,
            tools=TOOL_DEFINITIONS,
        )

        # Tool-use loop (max 3 rounds to keep latency bounded)
        rounds = 0
        while response.stop_reason == "tool_use" and rounds < 3:
            rounds += 1
            tool_results = []
            assistant_content = []
            for block in response.content:
                assistant_content.append(block)
                if block.type == "tool_use":
                    tools_used.append(block.name)
                    result = dispatch_tool(db, block.name, block.input)
                    for r in result.get("results", []) if isinstance(result, dict) else []:
                        title = r.get("source") or r.get("title") or r.get("document_title")
                        if title:
                            sources_seen[(title, r.get("category", ""))] = str(r)[:300]
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": json.dumps(result)[:4000],
                    })
            messages.append({"role": "assistant", "content": assistant_content})
            messages.append({"role": "user", "content": tool_results})
            response = client.messages.create(
                model=settings.llm_model,
                max_tokens=1000,
                system=system,
                messages=messages,
                tools=TOOL_DEFINITIONS,
            )

        answer_text = "".join(
            block.text for block in response.content if block.type == "text"
        ).strip() or NOT_FOUND_MESSAGE

    except APIError as e:
        answer_text = (
            "The AI service is temporarily unavailable, so I can't generate an answer right now. "
            "Please try again shortly."
        )
        confidence = "low"

    sources = [
        {"document_title": title, "category": cat, "snippet": snippet}
        for (title, cat), snippet in list(sources_seen.items())[:5]
    ]

    if answer_text.strip() == NOT_FOUND_MESSAGE:
        confidence = "low"

    return {
        "answer": answer_text,
        "sources": sources,
        "confidence": confidence,
        "tools_used": list(dict.fromkeys(tools_used)),
    }


def suggested_questions(db: Session) -> list[str]:
    """Smart suggested questions based on what's actually in the knowledge base."""
    from app.models.models import Document
    cats = {d.category for d in db.query(Document.category).distinct()}
    mapping = {
        "regulation": "What is the attendance requirement?",
        "syllabus": "What is the syllabus for this semester?",
        "notice": "What are the latest college notices?",
        "academic_calendar": "What are the important academic dates this term?",
        "examination": "What are the examination regulations?",
        "faq": "What are the frequently asked questions?",
    }
    qs = [v for k, v in mapping.items() if k in cats]
    if not qs:
        qs = list(mapping.values())[:4]
    return qs[:4]
