"""Simple, dependency-free notice summarizer.

Extracts a short summary, a likely date, and deadline-ish phrases from a
raw notice body using lightweight heuristics (no LLM call needed, so it
works instantly on upload).
"""
import re

DATE_PATTERN = re.compile(
    r"\b(\d{1,2}(st|nd|rd|th)?\s+(January|February|March|April|May|June|July|August|"
    r"September|October|November|December)[a-z]*\s*,?\s*\d{0,4}|"
    r"(January|February|March|April|May|June|July|August|September|October|November|December)"
    r"\s+\d{1,2}(st|nd|rd|th)?,?\s*\d{0,4}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
    re.IGNORECASE,
)

DEADLINE_KEYWORDS = ["last date", "deadline", "before", "due by", "on or before", "must be completed by"]
ACTION_KEYWORDS = ["must", "should", "required to", "need to", "kindly", "please"]


def summarize_notice(content: str) -> dict:
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', content) if s.strip()]
    summary = " ".join(sentences[:2]) if sentences else content[:200]

    dates = DATE_PATTERN.findall(content)
    important_date = dates[0][0] if dates and isinstance(dates[0], tuple) else (dates[0] if dates else "")
    if isinstance(important_date, tuple):
        important_date = important_date[0]

    deadline = ""
    for kw in DEADLINE_KEYWORDS:
        idx = content.lower().find(kw)
        if idx != -1:
            deadline = content[idx: idx + 80].strip()
            break

    required_action = ""
    for kw in ACTION_KEYWORDS:
        idx = content.lower().find(kw)
        if idx != -1:
            required_action = content[idx: idx + 100].strip()
            break

    return {
        "summary": summary[:400],
        "important_date": important_date[:60] if important_date else "",
        "deadline": deadline[:120],
        "required_action": required_action[:150],
    }
