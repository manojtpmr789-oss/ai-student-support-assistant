"""
Lightweight local vector store using TF-IDF + cosine similarity.

Why TF-IDF instead of a neural embedding model: this keeps the whole RAG
pipeline runnable completely offline with no extra API key and no large model
download, which matters for a class project that needs to run on any laptop.
The retrieval interface (`VectorStore.search`) is intentionally the same
shape you'd get from a real embedding-based store (Chroma/FAISS), so it can
be swapped later by re-implementing this one class -- see README.
"""
import os
import pickle
import threading
from dataclasses import dataclass
from typing import List, Optional

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.config import settings


@dataclass
class RetrievedChunk:
    chunk_id: str
    document_id: str
    document_title: str
    category: str
    content: str
    score: float


class VectorStore:
    """In-process TF-IDF index over all processed document chunks.

    Rebuilt whenever a document is (re)processed or deleted. Persisted to
    disk so a server restart doesn't require reprocessing every document.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self.vectorizer: Optional[TfidfVectorizer] = None
        self.matrix = None
        self.chunk_ids: List[str] = []
        self.chunk_meta: List[dict] = []
        os.makedirs(settings.vector_db_path, exist_ok=True)
        self._path = os.path.join(settings.vector_db_path, "tfidf_index.pkl")
        self._load()

    def _load(self):
        if os.path.exists(self._path):
            try:
                with open(self._path, "rb") as f:
                    data = pickle.load(f)
                self.vectorizer = data["vectorizer"]
                self.matrix = data["matrix"]
                self.chunk_ids = data["chunk_ids"]
                self.chunk_meta = data["chunk_meta"]
            except Exception:
                self.vectorizer = None

    def _save(self):
        with open(self._path, "wb") as f:
            pickle.dump({
                "vectorizer": self.vectorizer,
                "matrix": self.matrix,
                "chunk_ids": self.chunk_ids,
                "chunk_meta": self.chunk_meta,
            }, f)

    def rebuild(self, chunks: List[dict]):
        """chunks: list of dicts with id, document_id, document_title, category, content"""
        with self._lock:
            if not chunks:
                self.vectorizer = None
                self.matrix = None
                self.chunk_ids = []
                self.chunk_meta = []
                self._save()
                return
            texts = [c["content"] for c in chunks]
            self.vectorizer = TfidfVectorizer(
                stop_words="english", max_features=20000, ngram_range=(1, 2)
            )
            self.matrix = self.vectorizer.fit_transform(texts)
            self.chunk_ids = [c["id"] for c in chunks]
            self.chunk_meta = [
                {
                    "document_id": c["document_id"],
                    "document_title": c["document_title"],
                    "category": c["category"],
                    "content": c["content"],
                }
                for c in chunks
            ]
            self._save()

    def search(self, query: str, top_k: int = 4, category: Optional[str] = None,
               min_score: float = 0.05) -> List[RetrievedChunk]:
        if not self.vectorizer or self.matrix is None or self.matrix.shape[0] == 0:
            return []
        q_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(q_vec, self.matrix)[0]
        ranked = sorted(range(len(sims)), key=lambda i: sims[i], reverse=True)
        results = []
        for i in ranked:
            meta = self.chunk_meta[i]
            if category and meta["category"] != category:
                continue
            if sims[i] < min_score:
                continue
            results.append(RetrievedChunk(
                chunk_id=self.chunk_ids[i],
                document_id=meta["document_id"],
                document_title=meta["document_title"],
                category=meta["category"],
                content=meta["content"],
                score=float(sims[i]),
            ))
            if len(results) >= top_k:
                break
        return results


# Singleton used across the app
vector_store = VectorStore()
