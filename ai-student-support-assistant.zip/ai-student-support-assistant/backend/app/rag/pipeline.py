"""Document processing pipeline:
upload -> extract text -> clean -> chunk -> store chunks -> rebuild vector index
"""
from sqlalchemy.orm import Session
from app.models.models import Document, DocumentChunk
from app.rag.extract import extract_text, clean_text, chunk_text
from app.rag.vector_store import vector_store


def process_document(db: Session, document: Document):
    try:
        raw = extract_text(document.filepath)
        cleaned = clean_text(raw)
        chunks = chunk_text(cleaned)
        if not chunks:
            document.status = "failed"
            document.chunk_count = 0
            db.commit()
            return

        db.query(DocumentChunk).filter(DocumentChunk.document_id == document.id).delete()
        for idx, chunk in enumerate(chunks):
            db.add(DocumentChunk(
                document_id=document.id,
                document_title=document.title,
                category=document.category,
                chunk_index=idx,
                content=chunk,
            ))
        document.status = "processed"
        document.chunk_count = len(chunks)
        db.commit()
    except Exception:
        document.status = "failed"
        db.commit()
        raise
    finally:
        rebuild_vector_index(db)


def rebuild_vector_index(db: Session):
    rows = db.query(DocumentChunk).all()
    chunks = [
        {
            "id": r.id,
            "document_id": r.document_id,
            "document_title": r.document_title,
            "category": r.category,
            "content": r.content,
        }
        for r in rows
    ]
    vector_store.rebuild(chunks)


def delete_document_chunks(db: Session, document_id: str):
    db.query(DocumentChunk).filter(DocumentChunk.document_id == document_id).delete()
    db.commit()
    rebuild_vector_index(db)
