"""Read-only, student-facing view into processed knowledge-base documents,
grouped by category (used by the Syllabus and Regulations pages)."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, Document, DocumentChunk
from app.auth.security import get_current_user

router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])


@router.get("/{category}")
def get_by_category(category: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    docs = (
        db.query(Document)
        .filter(Document.category == category, Document.status == "processed")
        .order_by(Document.created_at.desc())
        .all()
    )
    result = []
    for d in docs:
        chunks = (
            db.query(DocumentChunk)
            .filter(DocumentChunk.document_id == d.id)
            .order_by(DocumentChunk.chunk_index.asc())
            .all()
        )
        result.append({
            "id": d.id,
            "title": d.title,
            "description": d.description,
            "content": "\n\n".join(c.content for c in chunks),
        })
    return {"documents": result}
