from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
import datetime

from app.database import get_db
from app.models.models import User, QueryLog, Document, ChatFeedback, Message
from app.auth.security import require_admin

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("")
def get_analytics(db: Session = Depends(get_db), user: User = Depends(require_admin)):
    total_questions = db.query(func.count(QueryLog.id)).scalar() or 0
    today = datetime.datetime.utcnow().date()
    questions_today = (
        db.query(func.count(QueryLog.id))
        .filter(func.date(QueryLog.created_at) == str(today))
        .scalar() or 0
    )
    total_documents = db.query(func.count(Document.id)).scalar() or 0
    unanswered = db.query(func.count(QueryLog.id)).filter(QueryLog.answered == False).scalar() or 0  # noqa: E712

    topic_rows = (
        db.query(QueryLog.topic_category, func.count(QueryLog.id))
        .group_by(QueryLog.topic_category)
        .order_by(func.count(QueryLog.id).desc())
        .limit(6)
        .all()
    )
    most_asked_topics = [{"topic": t or "general", "count": c} for t, c in topic_rows]

    thumbs_up = db.query(func.count(ChatFeedback.id)).filter(ChatFeedback.rating == "up").scalar() or 0
    thumbs_down = db.query(func.count(ChatFeedback.id)).filter(ChatFeedback.rating == "down").scalar() or 0

    confidence_rows = (
        db.query(QueryLog.confidence, func.count(QueryLog.id)).group_by(QueryLog.confidence).all()
    )
    confidence_breakdown = {c or "unknown": n for c, n in confidence_rows}

    total_responses = db.query(func.count(Message.id)).filter(Message.role == "assistant").scalar() or 0

    return {
        "total_questions": total_questions,
        "questions_today": questions_today,
        "total_documents": total_documents,
        "unanswered_questions": unanswered,
        "most_asked_topics": most_asked_topics,
        "user_feedback": {"up": thumbs_up, "down": thumbs_down},
        "confidence_breakdown": confidence_breakdown,
        "total_ai_responses": total_responses,
    }
