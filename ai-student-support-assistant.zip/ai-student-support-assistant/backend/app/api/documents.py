import os
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, BackgroundTasks
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, Document
from app.schemas.schemas import DocumentOut
from app.auth.security import require_admin
from app.rag.pipeline import process_document, delete_document_chunks
from app.config import settings

router = APIRouter(prefix="/api/documents", tags=["documents"])

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md"}
MAX_FILE_SIZE = 15 * 1024 * 1024  # 15 MB
VALID_CATEGORIES = {"regulation", "syllabus", "notice", "faq", "academic_calendar", "examination", "department", "general"}

UPLOAD_DIR = os.path.join(settings.knowledge_base_path, "_uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@router.get("", response_model=list[DocumentOut])
def list_documents(db: Session = Depends(get_db), user: User = Depends(require_admin)):
    return db.query(Document).order_by(Document.created_at.desc()).all()


@router.post("/upload", response_model=DocumentOut)
async def upload_document(
    background_tasks: BackgroundTasks,
    title: str = Form(...),
    description: str = Form(""),
    category: str = Form("general"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Unsupported file type '{ext}'. Allowed: PDF, DOCX, TXT, MD")
    if category not in VALID_CATEGORIES:
        raise HTTPException(status_code=400, detail=f"Invalid category. Allowed: {', '.join(sorted(VALID_CATEGORIES))}")

    contents = await file.read()
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail="File too large. Max size is 15 MB")
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    safe_name = f"{uuid.uuid4()}{ext}"
    filepath = os.path.join(UPLOAD_DIR, safe_name)
    with open(filepath, "wb") as f:
        f.write(contents)

    document = Document(
        title=title, description=description, category=category,
        filename=file.filename, filepath=filepath, status="processing",
        uploaded_by=user.id,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    try:
        process_document(db, document)
    except Exception:
        pass  # status already set to 'failed' inside process_document

    db.refresh(document)
    return document


@router.delete("/{document_id}")
def delete_document(document_id: str, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    delete_document_chunks(db, document_id)
    if os.path.exists(doc.filepath):
        try:
            os.remove(doc.filepath)
        except OSError:
            pass
    db.delete(doc)
    db.commit()
    return {"detail": "Document deleted"}


@router.get("/{document_id}", response_model=DocumentOut)
def get_document(document_id: str, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc
