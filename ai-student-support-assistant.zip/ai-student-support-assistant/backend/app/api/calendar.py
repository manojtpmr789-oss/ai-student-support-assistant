from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, DocumentChunk, Notice
from app.auth.security import get_current_user

router = APIRouter(prefix="/api/calendar", tags=["calendar"])


@router.get("")
def get_calendar(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    chunks = (
        db.query(DocumentChunk)
        .filter(DocumentChunk.category == "academic_calendar")
        .order_by(DocumentChunk.chunk_index.asc())
        .all()
    )
    upcoming = (
        db.query(Notice)
        .filter(Notice.deadline != "")
        .order_by(Notice.created_at.desc())
        .limit(10)
        .all()
    )
    return {
        "calendar_excerpts": [{"document_title": c.document_title, "content": c.content} for c in chunks],
        "upcoming_deadlines": [
            {"title": n.title, "date": n.important_date or n.deadline, "deadline": n.deadline}
            for n in upcoming
        ],
    }
