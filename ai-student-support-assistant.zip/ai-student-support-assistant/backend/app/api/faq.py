from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, FAQ
from app.schemas.schemas import FAQIn, FAQOut
from app.auth.security import require_admin, get_current_user

router = APIRouter(prefix="/api/faq", tags=["faq"])


@router.get("", response_model=list[FAQOut])
def list_faqs(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(FAQ).all()


@router.post("", response_model=FAQOut)
def create_faq(payload: FAQIn, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    faq = FAQ(question=payload.question, answer=payload.answer, category=payload.category, is_demo=False)
    db.add(faq)
    db.commit()
    db.refresh(faq)
    return faq


@router.delete("/{faq_id}")
def delete_faq(faq_id: str, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    faq = db.query(FAQ).filter(FAQ.id == faq_id).first()
    if not faq:
        raise HTTPException(status_code=404, detail="FAQ not found")
    db.delete(faq)
    db.commit()
    return {"detail": "FAQ deleted"}
