import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, Message, QueryLog
from app.schemas.schemas import ChatRequest, ChatResponse, SourceRef
from app.auth.security import get_current_user
from app.memory.memory import get_or_create_conversation
from app.services.llm import generate_answer, suggested_questions, NOT_FOUND_MESSAGE

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
def chat(payload: ChatRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    question = payload.message.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty")
    if len(question) > 2000:
        raise HTTPException(status_code=400, detail="Question is too long (max 2000 characters)")

    convo = get_or_create_conversation(db, user, payload.conversation_id, question)

    user_msg = Message(conversation_id=convo.id, role="user", content=question)
    db.add(user_msg)
    db.commit()

    try:
        result = generate_answer(db, user, question, convo.id)
    except Exception:
        result = {
            "answer": "Something went wrong while generating an answer. Please try again in a moment.",
            "sources": [], "confidence": "low", "tools_used": [],
        }

    assistant_msg = Message(
        conversation_id=convo.id,
        role="assistant",
        content=result["answer"],
        sources=json.dumps(result["sources"]),
        confidence=result["confidence"],
        tools_used=json.dumps(result["tools_used"]),
    )
    db.add(assistant_msg)

    db.add(QueryLog(
        question=question,
        answered=result["answer"] != NOT_FOUND_MESSAGE,
        confidence=result["confidence"],
        topic_category=(result["sources"][0]["category"] if result["sources"] else "general"),
    ))
    db.commit()
    db.refresh(assistant_msg)

    return ChatResponse(
        conversation_id=convo.id,
        message_id=assistant_msg.id,
        answer=result["answer"],
        sources=[SourceRef(**s) for s in result["sources"]],
        confidence=result["confidence"],
        tools_used=result["tools_used"],
        suggested_questions=suggested_questions(db),
    )
