import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, Conversation, Message, ChatFeedback
from app.schemas.schemas import FeedbackIn
from app.auth.security import get_current_user

router = APIRouter(prefix="/api/conversations", tags=["conversations"])


@router.get("")
def list_conversations(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    convos = (
        db.query(Conversation)
        .filter(Conversation.user_id == user.id)
        .order_by(Conversation.created_at.desc())
        .all()
    )
    return [{"id": c.id, "title": c.title, "created_at": c.created_at} for c in convos]


@router.get("/{conversation_id}")
def get_conversation(conversation_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    convo = db.query(Conversation).filter(Conversation.id == conversation_id, Conversation.user_id == user.id).first()
    if not convo:
        raise HTTPException(status_code=404, detail="Conversation not found")
    messages = (
        db.query(Message)
        .filter(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.asc())
        .all()
    )
    return {
        "id": convo.id,
        "title": convo.title,
        "messages": [
            {
                "id": m.id, "role": m.role, "content": m.content,
                "sources": json.loads(m.sources or "[]"),
                "confidence": m.confidence,
                "tools_used": json.loads(m.tools_used or "[]"),
                "created_at": m.created_at,
            }
            for m in messages
        ],
    }


@router.delete("/{conversation_id}")
def delete_conversation(conversation_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    convo = db.query(Conversation).filter(Conversation.id == conversation_id, Conversation.user_id == user.id).first()
    if not convo:
        raise HTTPException(status_code=404, detail="Conversation not found")
    db.delete(convo)
    db.commit()
    return {"detail": "Conversation deleted"}


@router.post("/feedback")
def submit_feedback(payload: FeedbackIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if payload.rating not in ("up", "down"):
        raise HTTPException(status_code=400, detail="rating must be 'up' or 'down'")
    fb = ChatFeedback(message_id=payload.message_id, rating=payload.rating)
    db.add(fb)
    db.commit()
    return {"detail": "Feedback recorded"}
