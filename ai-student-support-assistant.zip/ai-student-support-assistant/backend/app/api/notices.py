from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, Notice
from app.schemas.schemas import NoticeIn, NoticeOut
from app.auth.security import require_admin, get_current_user
from app.services.summarizer import summarize_notice

router = APIRouter(prefix="/api/notices", tags=["notices"])


@router.get("", response_model=list[NoticeOut])
def list_notices(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(Notice).order_by(Notice.created_at.desc()).all()


@router.post("", response_model=NoticeOut)
def create_notice(payload: NoticeIn, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    auto = summarize_notice(payload.content)
    notice = Notice(
        title=payload.title,
        content=payload.content,
        summary=auto["summary"],
        important_date=payload.important_date or auto["important_date"],
        target_students=payload.target_students,
        required_action=payload.required_action or auto["required_action"],
        deadline=payload.deadline or auto["deadline"],
        is_demo=False,
    )
    db.add(notice)
    db.commit()
    db.refresh(notice)
    return notice


@router.delete("/{notice_id}")
def delete_notice(notice_id: str, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    notice = db.query(Notice).filter(Notice.id == notice_id).first()
    if not notice:
        raise HTTPException(status_code=404, detail="Notice not found")
    db.delete(notice)
    db.commit()
    return {"detail": "Notice deleted"}
