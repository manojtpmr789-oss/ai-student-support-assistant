import datetime
import uuid
from sqlalchemy import Column, String, Integer, Text, DateTime, ForeignKey, Boolean, Float
from sqlalchemy.orm import relationship
from app.database import Base


def gen_id():
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=gen_id)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="student")  # student | admin
    preferred_style = Column(String, default="concise")  # concise | detailed
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    conversations = relationship("Conversation", back_populates="user")


class Document(Base):
    __tablename__ = "documents"
    id = Column(String, primary_key=True, default=gen_id)
    title = Column(String, nullable=False)
    description = Column(Text, default="")
    category = Column(String, default="general")
    filename = Column(String, nullable=False)
    filepath = Column(String, nullable=False)
    status = Column(String, default="processing")  # processing|processed|failed
    chunk_count = Column(Integer, default=0)
    uploaded_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class DocumentChunk(Base):
    __tablename__ = "document_chunks"
    id = Column(String, primary_key=True, default=gen_id)
    document_id = Column(String, ForeignKey("documents.id"), nullable=False)
    document_title = Column(String, nullable=False)
    category = Column(String, default="general")
    chunk_index = Column(Integer, default=0)
    content = Column(Text, nullable=False)


class Notice(Base):
    __tablename__ = "notices"
    id = Column(String, primary_key=True, default=gen_id)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    summary = Column(Text, default="")
    important_date = Column(String, default="")
    target_students = Column(String, default="All students")
    required_action = Column(String, default="")
    deadline = Column(String, default="")
    is_demo = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class FAQ(Base):
    __tablename__ = "faqs"
    id = Column(String, primary_key=True, default=gen_id)
    question = Column(String, nullable=False)
    answer = Column(Text, nullable=False)
    category = Column(String, default="general")
    is_demo = Column(Boolean, default=True)


class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(String, primary_key=True, default=gen_id)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    title = Column(String, default="New chat")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")


class Message(Base):
    __tablename__ = "messages"
    id = Column(String, primary_key=True, default=gen_id)
    conversation_id = Column(String, ForeignKey("conversations.id"), nullable=False)
    role = Column(String, nullable=False)  # user | assistant
    content = Column(Text, nullable=False)
    sources = Column(Text, default="[]")
    confidence = Column(String, default="")
    tools_used = Column(Text, default="[]")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    conversation = relationship("Conversation", back_populates="messages")


class ChatFeedback(Base):
    __tablename__ = "chat_feedback"
    id = Column(String, primary_key=True, default=gen_id)
    message_id = Column(String, ForeignKey("messages.id"), nullable=False)
    rating = Column(String, nullable=False)  # up | down
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class QueryLog(Base):
    __tablename__ = "query_logs"
    id = Column(String, primary_key=True, default=gen_id)
    question = Column(Text, nullable=False)
    answered = Column(Boolean, default=True)
    confidence = Column(String, default="")
    topic_category = Column(String, default="general")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
