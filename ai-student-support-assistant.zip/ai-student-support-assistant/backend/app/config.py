import os
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseSettings):
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./student_assistant.db")
    jwt_secret: str = os.getenv("JWT_SECRET", "dev_secret_change_me")
    jwt_algorithm: str = os.getenv("JWT_ALGORITHM", "HS256")
    access_token_expire_minutes: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))

    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_model: str = os.getenv("LLM_MODEL", "claude-sonnet-4-6")

    vector_db_path: str = os.getenv("VECTOR_DB_PATH", "./vector_store")
    knowledge_base_path: str = os.getenv("KNOWLEDGE_BASE_PATH", "./knowledge_base")

    default_admin_email: str = os.getenv("DEFAULT_ADMIN_EMAIL", "admin@college.edu")
    default_admin_password: str = os.getenv("DEFAULT_ADMIN_PASSWORD", "Admin@123")

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
