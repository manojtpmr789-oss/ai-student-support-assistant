"""
The 8 AI tools available to the assistant. Each tool is a plain Python
function; `TOOL_DEFINITIONS` describes them in Anthropic tool-use schema so
the LLM can decide when to call them, and `dispatch_tool` executes the call.
"""
import ast
import operator
import datetime
from sqlalchemy.orm import Session

from app.models.models import Notice, FAQ, DocumentChunk
from app.rag.vector_store import vector_store, RetrievedChunk


def _chunks_to_dicts(chunks: list[RetrievedChunk]) -> list[dict]:
    return [
        {
            "source": c.document_title,
            "category": c.category,
            "relevance": round(c.score, 3),
            "excerpt": c.content[:600],
        }
        for c in chunks
    ]


def notice_search_tool(db: Session, query: str) -> dict:
    rows = db.query(Notice).filter(Notice.content.ilike(f"%{query}%") | Notice.title.ilike(f"%{query}%")).limit(5).all()
    if not rows:
        chunks = vector_store.search(query, top_k=3, category="notice")
        return {"results": _chunks_to_dicts(chunks)}
    return {"results": [
        {"title": r.title, "summary": r.summary or r.content[:300], "deadline": r.deadline,
         "important_date": r.important_date, "target_students": r.target_students}
        for r in rows
    ]}


def regulation_search_tool(db: Session, query: str) -> dict:
    chunks = vector_store.search(query, top_k=4, category="regulation")
    return {"results": _chunks_to_dicts(chunks)}


def syllabus_search_tool(db: Session, query: str) -> dict:
    chunks = vector_store.search(query, top_k=4, category="syllabus")
    return {"results": _chunks_to_dicts(chunks)}


def faq_search_tool(db: Session, query: str) -> dict:
    rows = db.query(FAQ).filter(FAQ.question.ilike(f"%{query}%") | FAQ.answer.ilike(f"%{query}%")).limit(5).all()
    return {"results": [{"question": r.question, "answer": r.answer, "category": r.category} for r in rows]}


def academic_calendar_tool(db: Session, query: str) -> dict:
    chunks = vector_store.search(query, top_k=4, category="academic_calendar")
    return {"results": _chunks_to_dicts(chunks)}


def important_dates_tool(db: Session, topic: str = "") -> dict:
    notices = db.query(Notice).filter(Notice.deadline != "").order_by(Notice.created_at.desc()).limit(10).all()
    dates = [
        {"title": n.title, "date": n.important_date or n.deadline, "deadline": n.deadline,
         "target_students": n.target_students}
        for n in notices
    ]
    if topic:
        dates = [d for d in dates if topic.lower() in d["title"].lower()] or dates
    return {"important_dates": dates}


_ALLOWED_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.USub: operator.neg,
    ast.Mod: operator.mod,
}


def _safe_eval(node):
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError("Only numeric constants are allowed")
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_OPS:
        return _ALLOWED_OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_OPS:
        return _ALLOWED_OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError("Unsupported expression")


def calculator_tool(db: Session, expression: str) -> dict:
    try:
        tree = ast.parse(expression, mode="eval")
        result = _safe_eval(tree.body)
        return {"expression": expression, "result": result}
    except Exception as e:
        return {"expression": expression, "error": f"Could not evaluate: {e}"}


def document_search_tool(db: Session, query: str, category: str = "") -> dict:
    chunks = vector_store.search(query, top_k=5, category=category or None)
    return {"results": _chunks_to_dicts(chunks)}


TOOL_FUNCTIONS = {
    "notice_search_tool": notice_search_tool,
    "regulation_search_tool": regulation_search_tool,
    "syllabus_search_tool": syllabus_search_tool,
    "faq_search_tool": faq_search_tool,
    "academic_calendar_tool": academic_calendar_tool,
    "important_dates_tool": important_dates_tool,
    "calculator_tool": calculator_tool,
    "document_search_tool": document_search_tool,
}

TOOL_DEFINITIONS = [
    {
        "name": "notice_search_tool",
        "description": "Search official college notices (exam schedules, holidays, circulars) for a topic.",
        "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    },
    {
        "name": "regulation_search_tool",
        "description": "Search college regulation documents (attendance rules, passing criteria, discipline, exam regulations).",
        "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    },
    {
        "name": "syllabus_search_tool",
        "description": "Search syllabus documents for subjects, units, credits, and semester content.",
        "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    },
    {
        "name": "faq_search_tool",
        "description": "Search the college's frequently asked questions.",
        "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    },
    {
        "name": "academic_calendar_tool",
        "description": "Search the academic calendar for term dates, holidays, and scheduled events.",
        "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    },
    {
        "name": "important_dates_tool",
        "description": "Get a list of upcoming important academic deadlines/dates, optionally filtered by topic (e.g. 'exam', 'fee').",
        "input_schema": {"type": "object", "properties": {"topic": {"type": "string"}}, "required": []},
    },
    {
        "name": "calculator_tool",
        "description": "Evaluate a numeric arithmetic expression, e.g. for computing required attendance percentage or credit totals.",
        "input_schema": {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]},
    },
    {
        "name": "document_search_tool",
        "description": "General-purpose search across ALL uploaded college documents regardless of category. Use this when the question doesn't clearly map to one specific tool above.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}, "category": {"type": "string", "description": "optional category filter"}},
            "required": ["query"],
        },
    },
]


def dispatch_tool(db: Session, name: str, tool_input: dict) -> dict:
    fn = TOOL_FUNCTIONS.get(name)
    if not fn:
        return {"error": f"Unknown tool: {name}"}
    return fn(db, **tool_input)
