from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.database import Base, engine
from app.seed import seed
from app.api import auth, documents, notices, faq, calendar, chat, conversations, analytics, knowledge

app = FastAPI(title="AI Student Support Assistant API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # demo only - restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)
    seed()


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Never leak raw backend errors/stack traces to the client.
    return JSONResponse(status_code=500, content={"detail": "Something went wrong on the server. Please try again."})


app.include_router(auth.router)
app.include_router(documents.router)
app.include_router(notices.router)
app.include_router(faq.router)
app.include_router(calendar.router)
app.include_router(chat.router)
app.include_router(conversations.router)
app.include_router(analytics.router)
app.include_router(knowledge.router)


@app.get("/api/health")
def health():
    return {"status": "ok"}
