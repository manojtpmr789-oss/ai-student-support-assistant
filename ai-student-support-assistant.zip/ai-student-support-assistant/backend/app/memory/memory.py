"""
Conversation memory.

- Short-term / session memory: last N turns of a conversation are pulled
  from the DB and replayed to the LLM so follow-up questions like
  "what happens if I have less than that?" resolve correctly.
- Persistent preference memory: `User.preferred_style` (concise/detailed)
  is stored on the user record and applied to every future answer.

Nothing sensitive (IDs, grades, personal records) is put in the memory
context -- only the text of the chat itself.
"""
from sqlalchemy.orm import Session
from app.models.models import Conversation, Message, User

MAX_HISTORY_TURNS = 6


def get_recent_history(db: Session, conversation_id: str) -> list[dict]:
    msgs = (
        db.query(Message)
        .filter(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.asc())
        .all()
    )
    recent = msgs[-(MAX_HISTORY_TURNS * 2):]
    return [{"role": m.role, "content": m.content} for m in recent]


def get_or_create_conversation(db: Session, user: User, conversation_id: str | None, first_message: str) -> Conversation:
    if conversation_id:
        convo = db.query(Conversation).filter(
            Conversation.id == conversation_id, Conversation.user_id == user.id
        ).first()
        if convo:
            return convo
    title = (first_message[:50] + "...") if len(first_message) > 50 else first_message
    convo = Conversation(user_id=user.id, title=title or "New chat")
    db.add(convo)
    db.commit()
    db.refresh(convo)
    return convo


def style_instruction(user: User) -> str:
    if user.preferred_style == "detailed":
        return "The student prefers detailed, thorough explanations with full context."
    return "The student prefers short, concise, to-the-point answers with bullet points where useful."
